from __future__ import annotations

import os
import re
from pathlib import Path
from datetime import datetime, timedelta, timezone
from typing import Any

import httpx


def _load_env_file() -> None:
    """Load ../.env into os.environ so the app works however uvicorn is launched."""
    path = Path(__file__).resolve().parent.parent / ".env"
    if not path.exists():
        return
    for line in path.read_text(encoding="utf-8-sig").splitlines():
        line = line.strip()
        if not line or line.startswith("#") or "=" not in line:
            continue
        key, value = line.split("=", 1)
        os.environ.setdefault(key.strip(), value.strip().strip('"').strip("'"))


_load_env_file()


class SupabaseRepository:
    def __init__(self) -> None:
        self.url = os.getenv("SUPABASE_URL", "").rstrip("/")
        self.anon_key = os.getenv("SUPABASE_ANON_KEY", "")
        self.service_key = os.getenv("SUPABASE_SERVICE_ROLE_KEY", "")
        self.auth_configured = bool(self.url and self.anon_key)
        self.configured = bool(self.url and self.anon_key and self.service_key)
        self.last_database_error: str | None = None

    def _headers(self) -> dict[str, str]:
        return {
            "apikey": self.service_key,
            "Authorization": f"Bearer {self.service_key}",
            "Content-Type": "application/json",
        }

    async def insert(self, table: str, payload: dict[str, Any]) -> bool:
        if not self.configured:
            return False
        try:
            async with httpx.AsyncClient(timeout=8) as client:
                response = await client.post(
                    f"{self.url}/rest/v1/{table}",
                    headers={**self._headers(), "Prefer": "return=minimal"},
                    json=payload,
                )
            if response.is_error:
                self.last_database_error = f"insert {table} failed: {response.status_code} {response.text[:300]}"
                print(self.last_database_error)
                return False
            self.last_database_error = None
            return True
        except httpx.HTTPError as exc:
            self.last_database_error = f"insert {table} error: {exc}"
            print(self.last_database_error)
            return False

    def _fail(self, step: str, response: "httpx.Response") -> bool:
        self.last_database_error = f"users {step} failed: {response.status_code} {response.text[:300]}"
        print(self.last_database_error)
        return False

    async def sync_user(self, payload: dict[str, Any]) -> bool:
        """บันทึก/อัปเดตผู้ใช้ในตาราง public.users (คอลัมน์ openId เป็นตัวระบุ)."""
        if not self.configured:
            return False
        headers = {**self._headers(), "Prefer": "return=minimal"}
        try:
            async with httpx.AsyncClient(timeout=8) as client:
                lookup = await client.get(
                    f"{self.url}/rest/v1/users",
                    headers=self._headers(),
                    params={"select": "id", "openId": f"eq.{payload['openId']}", "limit": "1"},
                )
                if lookup.is_error:
                    return self._fail("lookup", lookup)
                rows = lookup.json()
                if rows:
                    response = await client.patch(
                        f"{self.url}/rest/v1/users", headers=headers,
                        params={"id": f"eq.{rows[0]['id']}"}, json=payload,
                    )
                else:
                    response = await client.post(f"{self.url}/rest/v1/users", headers=headers, json=payload)
                if response.is_error:
                    return self._fail("write", response)
            self.last_database_error = None
            return True
        except (httpx.HTTPError, KeyError, ValueError) as exc:
            self.last_database_error = f"users sync error: {exc}"
            print(self.last_database_error)
            return False

    async def touch_presence(self, visitor_id: str) -> bool:
        if not self.configured:
            return False
        try:
            async with httpx.AsyncClient(timeout=8) as client:
                response = await client.post(
                    f"{self.url}/rest/v1/online_visitors",
                    headers={**self._headers(), "Prefer": "resolution=merge-duplicates,return=minimal"},
                    params={"on_conflict": "id"},
                    json={"id": visitor_id, "last_seen": datetime.now(timezone.utc).isoformat()},
                )
                response.raise_for_status()
            self.last_database_error = None
            return True
        except httpx.HTTPError:
            self.last_database_error = "presence_table_unavailable"
            print("presence failed")
            return False

    async def _count(self, table: str, filters: dict[str, str] | None = None) -> int | None:
        if not self.configured:
            return None
        headers = {**self._headers(), "Prefer": "count=exact"}
        params = {"select": "id", "limit": "1", **(filters or {})}
        try:
            async with httpx.AsyncClient(timeout=8) as client:
                response = await client.get(f"{self.url}/rest/v1/{table}", headers=headers, params=params)
                response.raise_for_status()
            total = response.headers.get("content-range", "*/0").rsplit("/", 1)[-1]
            return int(total) if total.isdigit() else 0
        except (httpx.HTTPError, ValueError) as exc:
            self.last_database_error = f"count {table} failed: {exc}"
            print(self.last_database_error)
            return None

    async def stats(self) -> dict[str, int | None]:
        self.last_database_error = None
        online_since = (datetime.now(timezone.utc) - timedelta(minutes=2)).isoformat()
        return {
            "users": await self._count("users"),  # ผู้สมัคร = แถวในตาราง users
            "views": await self._count("page_views"),  # ยอดเข้าชมสะสม
            "online": await self._count("online_visitors", {"last_seen": f"gt.{online_since}"}),
        }

    async def upsert_news(self, record: dict[str, Any]) -> dict[str, Any] | None:
        """เพิ่มข่าวลง tcas_news หรืออัปเดตแถวเดิมถ้า source_url ซ้ำ (ต้องรัน migration 005 ก่อน).

        คืน dict ของแถวที่บันทึก หรือ None เมื่อล้มเหลว (ดูสาเหตุที่ last_database_error)
        """
        if not self.configured:
            return None
        try:
            async with httpx.AsyncClient(timeout=10) as client:
                response = await client.post(
                    f"{self.url}/rest/v1/tcas_news",
                    headers={**self._headers(), "Prefer": "resolution=merge-duplicates,return=representation"},
                    params={"on_conflict": "source_url"},
                    json=record,
                )
            if response.is_error:
                self.last_database_error = f"upsert news failed: {response.status_code} {response.text[:300]}"
                print(self.last_database_error)
                return None
            rows = response.json()
            self.last_database_error = None
            return rows[0] if rows else {}
        except (httpx.HTTPError, ValueError) as exc:
            self.last_database_error = f"upsert news error: {exc}"
            print(self.last_database_error)
            return None

    async def news(self, q: str = "", limit: int = 50) -> list[dict[str, Any]] | None:
        """ดึงข่าวล่าสุดจากตาราง tcas_news (ใหม่สุดก่อน) คืน None ถ้าอ่านไม่สำเร็จ."""
        if not self.configured:
            return None
        params: dict[str, str] = {
            "select": "id,title,content,source_url,news_date,image_url,pdf_url,created_at",
            "order": "id.desc",  # news_date/created_at เป็น text จึงเรียงด้วย id แทน
            "limit": str(max(1, min(limit, 100))),
        }
        # ตัดอักขระที่มีความหมายใน PostgREST filter (, ( ) * % \) ออกก่อนค้นหา
        needle = re.sub(r"[,()*%\\]", " ", q).strip()
        if needle:
            params["or"] = f"(title.ilike.*{needle}*,content.ilike.*{needle}*)"
        try:
            async with httpx.AsyncClient(timeout=8) as client:
                response = await client.get(f"{self.url}/rest/v1/tcas_news", headers=self._headers(), params=params)
                response.raise_for_status()
                rows = response.json()
        except (httpx.HTTPError, ValueError) as exc:
            self.last_database_error = f"read tcas_news failed: {exc}"
            print(self.last_database_error)
            return None
        self.last_database_error = None
        for row in rows:  # ไม่ส่งเนื้อหาเต็มในรายการ: ย่อเป็น summary
            text = " ".join((row.pop("content", None) or "").split())
            row["summary"] = text if len(text) <= 160 else text[:159].rstrip() + "…"
        return rows


    # ---------- helpers ทั่วไป (ใช้กับระบบบัญชี) ----------
    async def select(self, table: str, params: dict[str, str]) -> list[dict[str, Any]] | None:
        """อ่านแถวจากตาราง คืน None เมื่อล้มเหลว (ดู last_database_error)."""
        if not self.configured:
            return None
        try:
            async with httpx.AsyncClient(timeout=8) as client:
                response = await client.get(f"{self.url}/rest/v1/{table}", headers=self._headers(), params=params)
            if response.is_error:
                self.last_database_error = f"select {table} failed: {response.status_code} {response.text[:300]}"
                print(self.last_database_error)
                return None
            self.last_database_error = None
            return response.json()
        except (httpx.HTTPError, ValueError) as exc:
            self.last_database_error = f"select {table} error: {exc}"
            print(self.last_database_error)
            return None

    async def upsert(self, table: str, record: dict[str, Any], on_conflict: str) -> dict[str, Any] | None:
        """เพิ่มหรืออัปเดตแถวตาม on_conflict คืนแถวที่บันทึก หรือ None เมื่อล้มเหลว."""
        if not self.configured:
            return None
        try:
            async with httpx.AsyncClient(timeout=8) as client:
                response = await client.post(
                    f"{self.url}/rest/v1/{table}",
                    headers={**self._headers(), "Prefer": "resolution=merge-duplicates,return=representation"},
                    params={"on_conflict": on_conflict},
                    json=record,
                )
            if response.is_error:
                self.last_database_error = f"upsert {table} failed: {response.status_code} {response.text[:300]}"
                print(self.last_database_error)
                return None
            rows = response.json()
            self.last_database_error = None
            return rows[0] if rows else {}
        except (httpx.HTTPError, ValueError) as exc:
            self.last_database_error = f"upsert {table} error: {exc}"
            print(self.last_database_error)
            return None

    async def update(self, table: str, params: dict[str, str], record: dict[str, Any]) -> bool:
        if not self.configured:
            return False
        try:
            async with httpx.AsyncClient(timeout=8) as client:
                response = await client.patch(
                    f"{self.url}/rest/v1/{table}",
                    headers={**self._headers(), "Prefer": "return=minimal"},
                    params=params,
                    json=record,
                )
            if response.is_error:
                self.last_database_error = f"update {table} failed: {response.status_code} {response.text[:300]}"
                print(self.last_database_error)
                return False
            self.last_database_error = None
            return True
        except httpx.HTTPError as exc:
            self.last_database_error = f"update {table} error: {exc}"
            print(self.last_database_error)
            return False
