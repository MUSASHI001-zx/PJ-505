from __future__ import annotations

from typing import Any

from pydantic import BaseModel, ConfigDict, Field, field_validator

_EMPTY_MARKERS = {"", "null", "none", "undefined", "n/a"}


def _blank_to_none(value: Any) -> Any:
    """Make.com มักส่งช่องที่ไม่มีค่ามาเป็น "" หรือสตริง "null" — แปลงเป็น None."""
    if value is None:
        return None
    if isinstance(value, str) and value.strip().lower() in _EMPTY_MARKERS:
        return None
    return value.strip() if isinstance(value, str) else value


def _check_http_url(value: str, field: str) -> str:
    if not value.lower().startswith(("http://", "https://")) or " " in value:
        raise ValueError(f"{field} ต้องเป็นลิงก์ที่ขึ้นต้นด้วย http:// หรือ https://")
    if len(value) > 2048:
        raise ValueError(f"{field} ยาวเกินไป")
    return value


class NewsWebhookPayload(BaseModel):
    """Payload ที่ Make.com ส่งมาที่ POST /api/news"""

    model_config = ConfigDict(extra="ignore", str_strip_whitespace=True)

    title: str = Field(min_length=1, max_length=500, description="หัวข้อข่าว")
    content: str = Field(min_length=1, description="เนื้อหาข่าว")
    image_url: str | None = Field(default=None, description="ลิงก์รูปภาพ (ไม่มี/null ได้)")
    pdf_url: str | None = Field(default=None, description="ลิงก์ไฟล์ PDF (ไม่มี/null ได้)")
    source_url: str = Field(description="ลิงก์ต้นทางข่าวบน myTCAS (ใช้กันข่าวซ้ำ)")
    news_date: str | None = Field(default=None, max_length=100, description="วันที่ข่าว (ข้อความ ไม่มีก็ได้)")

    @field_validator("news_date", mode="before")
    @classmethod
    def _optional_text(cls, value: Any) -> Any:
        return _blank_to_none(value)

    @field_validator("image_url", "pdf_url", mode="before")
    @classmethod
    def _optional_url(cls, value: Any, info: Any) -> str | None:
        value = _blank_to_none(value)
        return None if value is None else _check_http_url(str(value), info.field_name)

    @field_validator("source_url", mode="before")
    @classmethod
    def _required_url(cls, value: Any) -> str:
        value = _blank_to_none(value)
        if value is None:
            raise ValueError("source_url ห้ามว่าง")
        return _check_http_url(str(value), "source_url")


class NewsWebhookResponse(BaseModel):
    ok: bool = True
    id: str | None = None
    source_url: str


class AccountUpdate(BaseModel):
    """ฟิลด์ที่ผู้ใช้แก้ได้ที่ PUT /api/account (ส่งเฉพาะฟิลด์ที่ต้องการเปลี่ยนได้)"""

    model_config = ConfigDict(extra="ignore", str_strip_whitespace=True)

    display_name: str | None = Field(default=None, max_length=60)
    avatar_key: str | None = Field(default=None, max_length=40, pattern=r"^[A-Za-z0-9_-]+$")
    school: str | None = Field(default=None, max_length=120)
    grade_level: str | None = Field(default=None, max_length=40)
    classroom: str | None = Field(default=None, max_length=40)
    interested_faculties: list[str] | None = Field(default=None, max_length=10)
    notify_prefs: dict[str, bool] | None = None


class InviteCreate(BaseModel):
    model_config = ConfigDict(extra="ignore", str_strip_whitespace=True)

    label: str | None = Field(default=None, max_length=60)
    max_uses: int | None = Field(default=None, ge=1, le=1000)
    expires_in_days: int | None = Field(default=None, ge=1, le=365)


class InviteRedeem(BaseModel):
    model_config = ConfigDict(extra="ignore", str_strip_whitespace=True)

    code: str = Field(min_length=4, max_length=40, pattern=r"^[A-Za-z0-9_-]+$")
