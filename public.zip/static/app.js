const $ = (selector, root = document) => root.querySelector(selector);
const $$ = (selector, root = document) => [...root.querySelectorAll(selector)];
let currentSession = null;
let supabaseClient = null;

window.addEventListener('DOMContentLoaded', () => {
  window.setTimeout(() => $('#app-loading')?.classList.add('hide'), 420);
  $('#mobile-menu')?.addEventListener('click', () => $('#sidebar')?.classList.toggle('open'));
  const modal = $('#login-modal');
  $('#login-btn')?.addEventListener('click', () => {
    if (currentSession) $('#account-menu')?.toggleAttribute('hidden');
    else modal?.classList.add('open');
  });
  document.addEventListener('click', (event) => {
    const menu = $('#account-menu');
    if (menu && !menu.hidden && !menu.contains(event.target) && !$('#login-btn')?.contains(event.target)) menu.hidden = true;
  });
  $('#logout-btn')?.addEventListener('click', signOut);
  $('#account-profile')?.addEventListener('click', () => { window.location.href = '/account'; });
  rememberInviteFromUrl();
  $$('[data-account-role]').forEach((button) => button.addEventListener('click', () => changeAccountRole(button.dataset.accountRole)));
  $$('[data-close-modal]').forEach((button) => button.addEventListener('click', () => modal?.classList.remove('open')));
  modal?.addEventListener('click', (event) => { if (event.target === modal) modal.classList.remove('open'); });
  $('#google-login')?.addEventListener('click', startGoogleLogin);
  $('#google-login-page')?.addEventListener('click', startGoogleLogin);
  $$('.bookmark').forEach((button) => button.addEventListener('click', () => { button.textContent = button.textContent.trim() === '♡' ? '♥' : '♡'; button.classList.toggle('saved'); }));
  $$('.choice-grid button').forEach((button) => button.addEventListener('click', () => { $$('.choice-grid button').forEach((item) => item.classList.remove('selected')); button.classList.add('selected'); button.style.background = '#f1efff'; button.style.borderColor = '#9383de'; }));
  $('#follow-news')?.addEventListener('click', (event) => { event.currentTarget.textContent = '✓ กำลังติดตามข่าว'; event.currentTarget.classList.add('primary'); });
  $('#global-search')?.addEventListener('keydown', (event) => { if (event.key === 'Enter' && event.currentTarget.value.trim()) window.location.href = `/news?q=${encodeURIComponent(event.currentTarget.value.trim())}`; });
  $$('.filter[data-news-filter]').forEach((button) => button.addEventListener('click', () => { $$('.filter[data-news-filter]').forEach((item) => item.classList.remove('active')); button.classList.add('active'); applyNewsFilters(button.dataset.newsFilter, new URLSearchParams(window.location.search).get('q') || ''); }));
  applyNewsFilters('ทั้งหมด', new URLSearchParams(window.location.search).get('q') || '');
  loadNews();
  initMetrics();
  restoreSupabaseSession();
});

async function restoreSupabaseSession() {
  const hasOAuthReturn = window.location.hash.includes('access_token') || window.location.hash.includes('code=');
  const status = $('#login-page-status') || $('#login-status');
  try {
    const configResponse = await fetch('/api/config');
    const config = await configResponse.json();
    if (!config.configured || !config.supabase_url || !config.supabase_anon_key) { announceGuest('not_configured'); return; }
    if (!window.supabase) {
      await new Promise((resolve, reject) => {
        const script = document.createElement('script');
        script.src = 'https://cdn.jsdelivr.net/npm/@supabase/supabase-js@2';
        script.onload = resolve;
        script.onerror = reject;
        document.head.appendChild(script);
      });
    }
    supabaseClient = window.supabase.createClient(config.supabase_url, config.supabase_anon_key);
    const { data, error } = await supabaseClient.auth.getSession();
    if (error) throw error;
    if (!data.session) {
      if (hasOAuthReturn) throw new Error('ไม่พบ session');
      announceGuest('signed_out');
      return;
    }
    currentSession = data.session;
    applyUserIdentity(data.session.user);
    await syncUserToBackend(data.session);
    await loadMyAccount();
    const inviteMessage = await redeemPendingInvite();
    if (inviteMessage) {
      if (hasOAuthReturn) { try { window.localStorage.setItem('tcas_buddy_toast', inviteMessage); } catch { /* ignore */ } }
      else toast(inviteMessage);
    }
    if (hasOAuthReturn) {
      window.history.replaceState({}, document.title, window.location.pathname);
      window.location.replace('/');
    }
  } catch {
    if (status) status.textContent = 'ยืนยันบัญชีไม่สำเร็จ โปรดลองเข้าสู่ระบบอีกครั้ง';
    announceGuest('error');
  }
}

async function syncUserToBackend(session, role = null) {
  try {
    const response = await fetch('/api/auth/sync', {
      method: 'POST',
      headers: { 'Content-Type': 'application/json', Authorization: `Bearer ${session.access_token}` },
      body: JSON.stringify(role ? { role } : {}),
    });
    if (!response.ok) {
      const err = await response.json().catch(() => ({}));
      throw new Error(err.detail || `sync failed (${response.status})`);
    }
  } catch (e) {
    console.error('user sync failed:', e);
  }
}

function applyUserIdentity(user) {
  const metadata = user.user_metadata || {};
  const name = metadata.full_name || metadata.name || user.email?.split('@')[0] || 'ผู้ใช้';
  const initial = name.trim().charAt(0).toUpperCase() || 'U';
  $('#profile-name') && ($('#profile-name').textContent = name);
  $('#profile-role') && ($('#profile-role').textContent = 'บัญชี Google');
  $('#header-name') && ($('#header-name').textContent = name);
  $('#header-email') && ($('#header-email').textContent = user.email || 'บัญชีของฉัน');
  ['#profile-avatar', '#header-avatar', '#menu-avatar'].forEach((selector) => { const node = $(selector); if (node) node.textContent = initial; });
  $('#menu-name') && ($('#menu-name').textContent = name);
  $('#menu-email') && ($('#menu-email').textContent = user.email || '');
}

async function changeAccountRole(role) {
  if (!currentSession || !['student', 'parents', 'teacher'].includes(role)) return;
  await syncUserToBackend(currentSession, role);
  const labels = { student: 'นักเรียน', parents: 'ผู้ปกครอง', teacher: 'คุณครู' };
  $('#profile-role') && ($('#profile-role').textContent = labels[role]);
  $('#account-menu')?.toggleAttribute('hidden');
}

async function signOut() {
  if (supabaseClient) await supabaseClient.auth.signOut();
  currentSession = null;
  window.location.href = '/login';
}

async function loadStats() {
  const cards = $$('[data-stat]');
  if (!cards.length) return;
  try {
    const response = await fetch('/api/stats');
    const data = await response.json();
    cards.forEach((card) => {
      const key = card.dataset.stat;
      card.textContent = data.configured && data[key] !== null ? Number(data[key]).toLocaleString('th-TH') : '—';
    });
    if (data.configured && data.database_ready === false) {
      const banner = $('#setup-banner');
      const copy = $('#setup-banner-copy');
      if (banner) banner.style.display = 'flex';
      if (copy) copy.textContent = 'เชื่อมต่อ Supabase แล้ว แต่ยังต้องรันไฟล์ migration เพื่อสร้างตารางข้อมูล';
    }
  } catch { cards.forEach((card) => { card.textContent = '—'; }); }
}

async function initMetrics() {
  await Promise.all([recordView(), recordPresence()]);
  await loadStats();
  window.setInterval(recordPresence, 30000);
  if ($$('[data-stat]').length) window.setInterval(loadStats, 30000);
  document.addEventListener('visibilitychange', () => { if (!document.hidden) recordPresence(); });
}

// นับ 1 ครั้งต่อการเข้าเว็บ 1 รอบ (ต่อแท็บ) และจะจำว่า "นับแล้ว" ก็ต่อเมื่อบันทึกลงฐานข้อมูลสำเร็จจริง
async function recordView() {
  const key = 'tcas_buddy_view_counted_v2';
  try { if (window.sessionStorage.getItem(key)) return; } catch { /* sessionStorage unavailable */ }
  try {
    const response = await fetch('/api/page-view', { method: 'POST', headers: {'Content-Type': 'application/json'}, body: JSON.stringify({ path: window.location.pathname }) });
    const data = await response.json().catch(() => ({}));
    if (response.ok && data.ok) { try { window.sessionStorage.setItem(key, '1'); } catch { /* ignore */ } }
  } catch { /* analytics is non-blocking */ }
}

function visitorId() {
  const key = 'tcas_buddy_visitor_id';
  let id = window.localStorage.getItem(key);
  if (!id) { id = crypto.randomUUID ? crypto.randomUUID() : `${Date.now()}-${Math.random()}`; window.localStorage.setItem(key, id); }
  return id;
}

async function recordPresence() {
  if (document.hidden) return;
  try { await fetch('/api/presence', { method: 'POST', headers: {'Content-Type': 'application/json'}, body: JSON.stringify({ visitor_id: visitorId() }) }); } catch { /* presence is non-blocking */ }
}

// ---------- ข่าวจากตาราง tcas_news (GET /api/news) ----------
const TONES = ['purple', 'blue', 'pink'];

function safeUrl(value) {
  try {
    const url = new URL(value, window.location.origin);
    return url.protocol === 'http:' || url.protocol === 'https:' ? url.href : null;
  } catch { return null; }
}

function el(tag, className, text) {
  const node = document.createElement(tag);
  if (className) node.className = className;
  if (text !== undefined) node.textContent = text;
  return node;
}

function newsDate(item) {
  if (item.news_date) return item.news_date;
  const created = item.created_at ? new Date(item.created_at) : null;
  return created && !Number.isNaN(created.getTime()) ? created.toLocaleDateString('th-TH', { day: 'numeric', month: 'short', year: 'numeric' }) : (item.created_at || '');
}

function openSource(url) {
  if (url) window.open(url, '_blank', 'noopener,noreferrer');
}

// ทำให้ทั้งการ์ดคลิกเปิด source_url ได้ (ยกเว้นเมื่อกดปุ่ม/ลิงก์ย่อยข้างใน)
function makeClickable(node, url) {
  if (!url) return;
  node.classList.add('live');
  node.addEventListener('click', (event) => {
    if (event.target.closest('a, button')) return;
    openSource(url);
  });
}

function titleLink(tag, item, url) {
  const heading = el(tag);
  if (url) {
    const link = el('a', '', item.title || '(ไม่มีหัวข้อ)');
    link.href = url; link.target = '_blank'; link.rel = 'noopener noreferrer';
    heading.append(link);
  } else heading.textContent = item.title || '(ไม่มีหัวข้อ)';
  return heading;
}

function imageNode(imageUrl, alt) {
  const img = el('img');
  img.src = imageUrl; img.alt = alt || ''; img.loading = 'lazy';
  img.addEventListener('error', () => img.parentElement?.classList.remove('has-image') || img.remove());
  return img;
}

function bookmarkButton() {
  const button = el('button', 'bookmark', '♡');
  button.type = 'button';
  button.addEventListener('click', () => { button.textContent = button.textContent.trim() === '♡' ? '♥' : '♡'; button.classList.toggle('saved'); });
  return button;
}

function buildNewsCard(item, index) {
  const url = safeUrl(item.source_url);
  const image = item.image_url && safeUrl(item.image_url);
  const pdf = item.pdf_url && safeUrl(item.pdf_url);
  const tone = TONES[index % TONES.length];
  const card = el('article', 'news-card');
  card.dataset.newsCard = '';
  card.dataset.search = `${item.title || ''} ${item.summary || ''}`;
  card.dataset.category = 'TCAS';
  const cover = el('div', `news-cover ${tone}`);
  if (image) { cover.classList.add('has-image'); cover.append(imageNode(image, item.title)); }
  else { cover.append(el('span', '', 'TCAS'), el('div', 'cover-orbit', '✦')); }
  const body = el('div', 'news-card-body');
  const meta = el('div', 'card-meta');
  meta.append(el('span', `tag-pill ${tone}`, 'TCAS'), bookmarkButton());
  const footer = el('div', 'card-footer');
  footer.append(el('small', '', newsDate(item)));
  const actions = el('span');
  if (pdf) {
    const pdfLink = el('a', 'pdf-link', 'PDF');
    pdfLink.href = pdf; pdfLink.target = '_blank'; pdfLink.rel = 'noopener noreferrer';
    actions.append(pdfLink);
  }
  if (url) actions.append('อ่านต่อ →');
  footer.append(actions);
  body.append(meta, titleLink('h3', item, url), el('p', '', item.summary || ''), footer);
  card.append(cover, body);
  makeClickable(card, url);
  return card;
}

function buildNewsRow(item, index) {
  const url = safeUrl(item.source_url);
  const image = item.image_url && safeUrl(item.image_url);
  const tone = TONES[index % TONES.length];
  const row = el('article', 'news-row');
  const thumb = el('div', `news-thumb ${tone}`);
  if (image) { thumb.classList.add('has-image'); thumb.append(imageNode(image, item.title)); }
  else { thumb.append(el('span', '', 'TCAS')); const b = el('b'); b.append('TCAS', document.createElement('br'), 'Buddy'); thumb.append(b); }
  const text = el('div');
  text.append(el('span', `tag-pill ${tone}`, 'TCAS'), titleLink('h4', item, url), el('p', '', item.summary || ''), el('small', '', newsDate(item)));
  row.append(thumb, text, bookmarkButton());
  makeClickable(row, url);
  return row;
}

async function loadNews() {
  const grid = $('#news-grid');
  const homeList = $('#home-news-list');
  if (!grid && !homeList) return;
  const query = new URLSearchParams(window.location.search).get('q') || '';
  const status = $('#news-status');
  try {
    const response = await fetch(`/api/news?limit=${grid ? 50 : 3}${query && grid ? `&q=${encodeURIComponent(query)}` : ''}`);
    if (!response.ok) throw new Error(`HTTP ${response.status}`);
    const data = await response.json();
    if (data.sample_mode) return; // ฐานข้อมูลยังไม่พร้อม: คงข่าวตัวอย่างที่ server render ไว้
    const items = data.items || [];
    if (grid) {
      $('#news-filter-row')?.setAttribute('hidden', ''); // tcas_news ไม่มีหมวดหมู่ จึงซ่อนตัวกรองหมวด
      grid.replaceChildren(...items.map(buildNewsCard));
      if (status) {
        status.hidden = items.length > 0;
        status.textContent = items.length ? '' : (query ? `ไม่พบข่าวที่ตรงกับ “${query}”` : 'ยังไม่มีข่าวในระบบ');
      }
    }
    if (homeList && items.length) homeList.replaceChildren(...items.slice(0, 3).map(buildNewsRow));
  } catch (error) {
    console.warn('โหลดข่าวไม่สำเร็จ ใช้ข่าวตัวอย่างแทน', error);
    if (status && grid) { status.hidden = false; status.textContent = 'โหลดข่าวล่าสุดไม่สำเร็จ กำลังแสดงข่าวตัวอย่าง'; }
  }
}

function applyNewsFilters(category, query) {
  const needle = query.trim().toLowerCase();
  $$('[data-news-card]').forEach((card) => {
    const matchesCategory = category === 'ทั้งหมด' || card.dataset.category === category;
    const matchesQuery = !needle || card.dataset.search.toLowerCase().includes(needle);
    card.style.display = matchesCategory && matchesQuery ? '' : 'none';
  });
}

async function startGoogleLogin() {
  const status = $('#login-page-status') || $('#login-status');
  if (status) status.textContent = 'กำลังตรวจสอบการตั้งค่า Google Login...';
  try {
    const response = await fetch('/api/config');
    const config = await response.json();
    if (!config.configured || !config.supabase_url || !config.supabase_anon_key) {
      if (status) status.textContent = 'ยังไม่ได้ตั้งค่า Supabase/Google provider — ดูขั้นตอนได้ที่ FAQ';
      return;
    }
    if (!window.supabase) {
      const script = document.createElement('script');
      script.src = 'https://cdn.jsdelivr.net/npm/@supabase/supabase-js@2';
      script.onload = () => launchSupabase(config);
      script.onerror = () => { if (status) status.textContent = 'โหลดตัวเชื่อมต่อ Supabase ไม่สำเร็จ'; };
      document.head.appendChild(script);
    } else launchSupabase(config);
  } catch { if (status) status.textContent = 'เชื่อมต่อการตั้งค่าไม่ได้ โปรดลองใหม่'; }
}

async function launchSupabase(config) {
  const status = $('#login-page-status') || $('#login-status');
  try {
    const client = window.supabase.createClient(config.supabase_url, config.supabase_anon_key);
    if (status) status.textContent = 'กำลังพาไปหน้า Google...';
    const { error } = await client.auth.signInWithOAuth({
      provider: 'google',
      options: { redirectTo: window.location.origin + window.location.pathname },
    });
    if (error) throw error;
  } catch (e) {
    console.error('Google login failed:', e);
    if (status) status.textContent = 'Login ไม่สำเร็จ: ' + (e.message || e);
  }
}


// ---------- ระบบบัญชี: ตัวช่วยกลาง (ใช้ร่วมกับ account.js) ----------
window.myAccount = null;

function announceGuest(reason) {
  document.dispatchEvent(new CustomEvent('account:guest', { detail: { reason } }));
}

async function accessToken() {
  if (supabaseClient) {
    const { data } = await supabaseClient.auth.getSession();
    if (data.session?.access_token) return data.session.access_token;
  }
  return currentSession?.access_token || null;
}

// เรียก API ที่ต้องล็อกอิน: แนบ Bearer token และโยน Error พร้อมข้อความภาษาไทยจาก backend
async function authFetch(path, options = {}) {
  const token = await accessToken();
  if (!token) throw new Error('ยังไม่ได้เข้าสู่ระบบ');
  const response = await fetch(path, {
    ...options,
    headers: { 'Content-Type': 'application/json', ...(options.headers || {}), Authorization: `Bearer ${token}` },
  });
  const data = await response.json().catch(() => ({}));
  if (!response.ok) throw new Error(typeof data.detail === 'string' ? data.detail : `เกิดข้อผิดพลาด (${response.status})`);
  return data;
}

function applyAvatar(profile) {
  ['#profile-avatar', '#header-avatar', '#menu-avatar'].forEach((selector) => {
    const node = $(selector);
    if (!node) return;
    if (profile.avatar_url) {
      node.classList.add('has-img');
      node.style.backgroundImage = `url("${profile.avatar_url}")`;
    } else {
      node.classList.remove('has-img');
      node.style.backgroundImage = '';
      node.textContent = (profile.display_name || 'U').trim().charAt(0).toUpperCase();
    }
  });
  const name = profile.display_name;
  if (name) {
    ['#profile-name', '#header-name', '#menu-name'].forEach((selector) => { const node = $(selector); if (node) node.textContent = name; });
  }
}

async function loadMyAccount() {
  try {
    const data = await authFetch('/api/account');
    window.myAccount = data.profile;
    applyAvatar(data.profile);
    document.dispatchEvent(new CustomEvent('account:ready', { detail: data.profile }));
  } catch (error) {
    console.warn('โหลดข้อมูลบัญชีไม่สำเร็จ', error);
    document.dispatchEvent(new CustomEvent('account:error', { detail: { message: error.message } }));
  }
}

let toastTimer = null;
function toast(message) {
  const node = $('#toast');
  if (!node) return;
  node.textContent = message;
  node.hidden = false;
  window.clearTimeout(toastTimer);
  toastTimer = window.setTimeout(() => { node.hidden = true; }, 3200);
}

// ลิงก์คำเชิญ: /invite/CODE -> /login?invite=CODE เก็บรหัสไว้จนกว่าจะล็อกอินสำเร็จ
const INVITE_KEY = 'tcas_buddy_pending_invite';
function rememberInviteFromUrl() {
  const code = new URLSearchParams(window.location.search).get('invite');
  if (!code || !/^[A-Za-z0-9_-]{4,40}$/.test(code)) return;
  try { window.localStorage.setItem(INVITE_KEY, code); } catch { /* storage unavailable */ }
  const status = $('#login-page-status');
  if (status) status.textContent = 'คุณได้รับคำเชิญ เข้าสู่ระบบเพื่อรับคำเชิญนี้';
}

async function redeemPendingInvite() {
  let code = null;
  try { code = window.localStorage.getItem(INVITE_KEY); } catch { return null; }
  if (!code) return null;
  let message;
  try {
    const result = await authFetch('/api/account/invites/redeem', { method: 'POST', body: JSON.stringify({ code }) });
    message = result.already ? 'คุณรับคำเชิญนี้ไว้แล้ว' : 'รับคำเชิญเรียบร้อย ยินดีต้อนรับ!';
  } catch (error) { message = error.message; }
  try { window.localStorage.removeItem(INVITE_KEY); } catch { /* ignore */ }
  return message;
}

window.addEventListener('DOMContentLoaded', () => {
  try {
    const pending = window.localStorage.getItem('tcas_buddy_toast');
    if (pending) { window.localStorage.removeItem('tcas_buddy_toast'); toast(pending); }
  } catch { /* ignore */ }
});
